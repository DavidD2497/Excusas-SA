package ar.edu.davinci.excusas.model.empleados.interfaces;

public interface IEncargado extends IEmpleado, IManejadorExcusas {
}

