package ar.edu.davinci.excusas.model.prontuarios.interfaces;

import ar.edu.davinci.excusas.model.prontuarios.Prontuario;

public interface IObserver {
    void actualizar(Prontuario prontuario);
}

