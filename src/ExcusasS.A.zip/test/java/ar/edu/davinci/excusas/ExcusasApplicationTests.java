package ar.edu.davinci.excusas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcusasApplicationTests {

	@Test
	void contextLoads() {
	}

}
