package ar.edu.davinci.excusas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcusasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcusasApplication.class, args);
	}

}
