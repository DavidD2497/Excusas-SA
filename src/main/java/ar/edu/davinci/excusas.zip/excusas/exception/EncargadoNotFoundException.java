package ar.edu.davinci.excusas.exception;

public class EncargadoNotFoundException extends RuntimeException {
    public EncargadoNotFoundException(String message) {
        super(message);
    }
}
